<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

include 'headeradmin.php';
include 'dbconnect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_GET['course_code'])) {
    $course_code = $_GET['course_code'];
    $course_name = $_POST['course_name'];
    $course_credit = $_POST['course_credit'];
    $lecturer = $_POST['lecturer'];
    $capacity = $_POST['capacity'];
    $semester = $_POST['semester'];

    $update_sql = "UPDATE tb_course SET c_name='$course_name', c_credit='$course_credit', c_lec='$lecturer', max='$capacity', semester='$semester' WHERE c_code='$course_code'";

    if (mysqli_query($con, $update_sql)) {
        header("Location: admincourse.php");  
        exit();
    } else {
        echo "Error updating course: " . mysqli_error($con);
    }
} else {
    echo "Invalid request!";
}
?>
