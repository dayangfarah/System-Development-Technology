<?php
include('dbconnect.php');

$funame = $_POST['funame']; 
$fpwd = $_POST['fpwd']; 
$fcpwd = $_POST['fcpwd']; 
$femail = $_POST['femail'];
$fname = $_POST['fname']; 
$fcontact = $_POST['fcontact']; 
$fstate = $_POST['fstate']; 
$futype = $_POST['futype']; 

if (empty($funame) || empty($fpwd) || empty($fcpwd) || empty($femail) || empty($fname) || empty($fcontact)) {
    echo "Error: All fields are required.";
    exit();
}

if (!filter_var($femail, FILTER_VALIDATE_EMAIL)) {
    echo "Error: Invalid email format.";
    exit();
}

if ($fpwd !== $fcpwd) {
    echo "Error: Passwords do not match. Please try again.";
    exit();
}

$hashed_password = password_hash($fpwd, PASSWORD_BCRYPT);

$verification_token = bin2hex(random_bytes(50)); // Generate a token


$sql_user = "INSERT INTO tb_user (u_sno, u_pwd, u_email, u_name, u_contact, u_state, u_req, u_utype, verification_token) 
        VALUES ('$funame', '$hashed_password', '$femail', '$fname', '$fcontact', '$fstate', CURRENT_TIMESTAMP(), '$futype', '$verification_token')";

if (mysqli_query($con, $sql_user)) {

    if ($futype == 2) { // Student
        $sql_student = "INSERT INTO student (u_sno, full_name, email, contact, state) 
                        VALUES ('$funame', '$fname', '$femail', '$fcontact', '$fstate')";
        mysqli_query($con, $sql_student);
    } elseif ($futype == 1) { // Lecturer
        $sql_lecturer = "INSERT INTO lecturer (u_sno, full_name, email, contact) 
                         VALUES ('$funame', '$fname', '$femail', '$fcontact')";
        mysqli_query($con, $sql_lecturer);
    } elseif ($futype == 3) { // Admin
        $sql_admin = "INSERT INTO admin (u_sno, full_name, email, contact) 
                      VALUES ('$funame', '$fname', '$femail', '$fcontact')";
        mysqli_query($con, $sql_admin);
    }

    $verification_link = "http://yourwebsite.com/verify.php?token=" . $verification_token;
    $subject = "Please verify your email address";
    $message = "Dear $fname,\n\nPlease click the link below to verify your email address and activate your account:\n$verification_link";
    $headers = "From: no-reply@yourwebsite.com";

    // Send email
    if (mail($femail, $subject, $message, $headers)) {
        echo "A verification link has been sent to your email. Please check your inbox to verify your account.";
    } else {
        echo "Error: Unable to send verification email.";
    }

    header('Location: login.php');
} else {
    echo "Error: " . mysqli_error($con);
}


mysqli_close($con);
?>
