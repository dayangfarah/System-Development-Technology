<?php
include 'dbconnect.php';
session_start();

$uic = $_SESSION['funame'];
$semester = $_POST['selected_semester'];
$selected_courses = isset($_POST['selected_courses']) ? $_POST['selected_courses'] : [];

if (empty($selected_courses)) {
    die("No courses selected!");
}

foreach ($selected_courses as $course_code) {
    $check_query = "SELECT * FROM tb_registration WHERE r_student='$uic' AND r_course='$course_code' AND r_sem='$semester'";
    $check_result = mysqli_query($con, $check_query);

    if (mysqli_num_rows($check_result) == 0) { 
        $sql = "INSERT INTO tb_registration (r_student, r_course, r_status, r_sem)
                VALUES ('$uic', '$course_code', '1', '$semester')";

        if (!mysqli_query($con, $sql)) {
            echo "Error inserting course: " . mysqli_error($con);
        }
    }
}

header("Location: addcourse.php?semester=$semester&status=success");
exit();
?>
