<?php
include('dbconnect.php');

if (isset($_GET['token'])) {
    $token = $_GET['token'];


    $sql = "SELECT * FROM tb_user WHERE verification_token = '$token' LIMIT 1";
    $result = mysqli_query($con, $sql);


    if (mysqli_num_rows($result) > 0) {

        $row = mysqli_fetch_assoc($result);
        $user_id = $row['u_id']; 

        $sql_verify = "UPDATE tb_user SET verified = 1, verification_token = NULL WHERE u_id = '$user_id'";
        if (mysqli_query($con, $sql_verify)) {
            echo "Your email has been verified successfully! You can now log in.";

            header('Location: login.php');
        } else {
            echo "Error: Could not verify your email. Please try again later.";
        }
    } else {
        echo "Invalid or expired token. Please check the link or request a new one.";
    }
} else {
    echo "Error: No token provided.";
}

mysqli_close($con);
?>
