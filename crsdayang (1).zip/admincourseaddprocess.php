<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

include 'dbconnect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $course_code = $_POST['course_code'];
    $course_name = $_POST['course_name'];
    $course_credit = $_POST['course_credit'];
    $lecturer = $_POST['lecturer'];
    $capacity = $_POST['capacity'];
    $semester = $_POST['semester'];

    $sql = "INSERT INTO tb_course (c_code, c_name, c_credit, c_lec, max, semester) 
            VALUES ('$course_code', '$course_name', '$course_credit', '$lecturer', '$capacity', '$semester')";

    if (mysqli_query($con, $sql)) {
        header("Location: admincourse.php"); 
        exit();
    } else {
        echo "Error adding course: " . mysqli_error($con);
    }
}
?>
