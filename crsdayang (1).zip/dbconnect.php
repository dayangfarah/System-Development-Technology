<?php
//Set DB Parameter
$servername = "localhost: 3307";
$username = "root";
$password = "";
$dbname = "db_crs";

//Connect DB
$con = mysqli_connect($servername, $username, $password, $dbname);

//Connection Check (continue as individual project)

?>