

<?php
include('crssession.php');

if (!session_id()) {
    session_start();    
}

include 'dbconnect.php';
include 'headerstudent.php';

// Check if session variable exists
if (!isset($_SESSION['u_sno'])) {
    echo "Error: Session not set. Please log in again.";
    exit;
}

$u_sno = $_SESSION['u_sno'];

// Fetch student data from the database
$query = "SELECT * FROM student WHERE u_sno = '$u_sno'";
$result = mysqli_query($con, $query);

if (!$result) {
    echo "Database query failed: " . mysqli_error($con);
    exit;
}

if (mysqli_num_rows($result) == 0) {
    echo "Error: Student not found in the database.";
    exit;
}

$student = mysqli_fetch_assoc($result);

// Check if form is submitted for profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $program = $_POST['program'];
    $year = $_POST['year'];
    $faculty = $_POST['faculty'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $address = $_POST['address'];
    $state = $_POST['state'];

    // Update student information in the database
    $update_sql = "UPDATE student 
                   SET full_name = '$full_name', program = '$program', year = '$year', 
                       faculty = '$faculty', gender = '$gender', Dob = '$dob', email = '$email', 
                       contact = '$contact', address = '$address', state = '$state'
                   WHERE u_sno = '$u_sno'";

    if (mysqli_query($con, $update_sql)) {
        echo "<p>Profile updated successfully.</p>";
        // Reload the page to reflect changes
        header("Location: profstudent.php");
        exit;
    } else {
        echo "<p>Error updating profile: " . mysqli_error($con) . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Student Profile</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <style>
    .footer {
       position: fixed;
       left: 0;
       bottom: 0;
       width: 100%;
       background-color: #d4d1ce;
       color: white;
       text-align: center;
    }
  </style>
</head>
<body>

<div class="container">
  <h3>Student Profile: <?php echo $student['full_name']; ?></h3>

  <!-- Profile Details Table -->
  <table class="table table-striped table-hover">
    <tbody>
      <tr>
        <th scope="row">Full Name</th>
        <td><?php echo $student['full_name']; ?></td>
      </tr>
      <tr>
        <th scope="row">Student ID</th>
        <td><?php echo $student['u_sno']; ?></td>
      </tr>
      <tr>
        <th scope="row">Programme Code</th>
        <td><?php echo $student['program']; ?></td>
      </tr>
      <tr>
        <th scope="row">Year</th>
        <td><?php echo $student['year']; ?></td>
      </tr>
      <tr>
        <th scope="row">Faculty</th>
        <td><?php echo $student['faculty']; ?></td>
      </tr>
      <tr>
        <th scope="row">Gender</th>
        <td><?php echo $student['gender']; ?></td>
      </tr>
      <tr>
        <th scope="row">Date of Birth</th>
        <td><?php echo $student['Dob']; ?></td>
      </tr>
      <tr>
        <th scope="row">Email</th>
        <td><?php echo $student['email']; ?></td>
      </tr>
      <tr>
        <th scope="row">Phone Number</th>
        <td><?php echo $student['contact']; ?></td>
      </tr>
      <tr>
        <th scope="row">Address</th>
        <td><?php echo $student['address']; ?></td>
      </tr>
      <tr>
        <th scope="row">State</th>
        <td><?php echo $student['state']; ?></td>
      </tr>
    </tbody>
  </table>

  <!-- Edit Profile Button -->
  <a href="editprofile.php" class="btn btn-primary">Update Profile</a>
</div>

<!-- Footer Section -->
<div class="footer">
  <p>Course Registration System &copy; 2025</p>
</div>

</body>
</html>
