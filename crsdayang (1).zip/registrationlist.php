<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

include 'headeradmin.php';
include 'dbconnect.php';

$search_term = isset($_GET['search']) ? $_GET['search'] : '';

$sql = "SELECT student.full_name, student.u_sno, tb_course.c_code, tb_course.c_name, tb_registration.r_status
        FROM tb_registration
        LEFT JOIN student ON tb_registration.r_student = student.u_sno
        LEFT JOIN tb_course ON tb_registration.r_course = tb_course.c_code
        WHERE student.u_sno LIKE '%$search_term%'";
$result = mysqli_query($con, $sql);
?>

<div class="container mt-3">
    <h3>Course Registration List</h3>

    <!-- Search Form -->
    <form method="GET" action="" class="form-inline mb-3">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search by Student ID" value="<?php echo $search_term; ?>">
            <div class="input-group-append">
                <button type="submit" class="btn btn-primary">Search</button>
            </div>
        </div>
    </form>

    <div class="mb-3">
        <input type="checkbox" id="selectAll" onclick="toggleAllCheckboxes(this)"> Select All
    </div>

    <form id="registrationForm" method="POST" action="registrationlistprocess.php">
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col"><input type="checkbox" onclick="toggleAllCheckboxes(this)"></th>
                    <th scope="col">Student Name</th>
                    <th scope="col">Student ID</th>
                    <th scope="col">Course Code</th>
                    <th scope="col">Course Name</th>
                    <th scope="col">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_array($result)) {
                    $statuscourse = $row['r_status'];  
                    
                    echo "<tr>";
                    echo "<td><input type='checkbox' name='selected_courses[]' value='" . $row['u_sno'] . "-" . $row['c_code'] . "' class='courseCheckbox'></td>";
                    echo "<td>" . $row['full_name'] . "</td>";
                    echo "<td>" . $row['u_sno'] . "</td>";
                    echo "<td>" . $row['c_code'] . "</td>";
                    echo "<td>" . $row['c_name'] . "</td>";

                    if ($statuscourse == 2) {
                        echo "<td>Approved</td>";
                    } elseif ($statuscourse == 3) {
                        echo "<td>Rejected</td>";
                    } elseif ($statuscourse == 4) {
                        echo "<td>Cancelled</td>";
                    } else {
                        echo "<td>Pending</td>";
                    }

                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>

        <div id="actionButtons" style="display: none;">
            <button type="submit" name="action" value="approve" class="btn btn-success btn-sm">Approve</button>
            <button type="submit" name="action" value="reject" class="btn btn-danger btn-sm">Reject</button>
            <button type="submit" name="action" value="cancel" class="btn btn-secondary btn-sm">Cancel</button>
        </div>
    </form>

    <div class="d-flex mt-4">
        <a href="admin.php" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Back
        </a>
    </div>
</div>

<script>
function toggleAllCheckboxes(source) {
    var checkboxes = document.querySelectorAll('.courseCheckbox');
    checkboxes.forEach(checkbox => {
        checkbox.checked = source.checked;
    });

    toggleActionButtons();
}

function toggleActionButtons() {
    var checkboxes = document.querySelectorAll('.courseCheckbox');
    var selectedCheckboxes = Array.from(checkboxes).filter(checkbox => checkbox.checked);
    var actionButtons = document.getElementById('actionButtons');
    
    if (selectedCheckboxes.length > 0) {
        actionButtons.style.display = 'block';
    } else {
        actionButtons.style.display = 'none';
    }
}

document.querySelectorAll('.courseCheckbox').forEach(checkbox => {
    checkbox.addEventListener('change', toggleActionButtons);
});
</script>


