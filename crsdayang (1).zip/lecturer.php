<?php 
include('crssession.php');
if(!session_id())
{
	session_start();
}
include 'headerlecturer.php'; 
?>
<div class="container">
Lecturer Page
</div>
<?php include 'footer.php' ?>