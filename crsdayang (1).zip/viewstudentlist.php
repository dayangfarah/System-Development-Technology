<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

include 'headerlecturer.php';
include 'dbconnect.php';

$course_code = isset($_GET['course_code']) ? $_GET['course_code'] : '';

$sql = "SELECT student.full_name, student.u_sno, tb_course.c_code, tb_course.c_name
        FROM tb_registration
        LEFT JOIN student ON tb_registration.r_student = student.u_sno
        LEFT JOIN tb_course ON tb_registration.r_course = tb_course.c_code
        WHERE tb_registration.r_course = '$course_code' AND tb_registration.r_status = 2"; 
$result = mysqli_query($con, $sql);
?>

<div class="container">
    <h3>Students Enrolled in Course: <?php echo $course_code; ?></h3>

    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th scope="col">Student Name</th>
                <th scope="col">Student ID</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = mysqli_fetch_array($result)) {
                echo "<tr>";
                echo "<td>" . $row['full_name'] . "</td>";
                echo "<td>" . $row['u_sno'] . "</td>";
                echo "<td><a href='studentprofile.php?u_sno=" . $row['u_sno'] . "&c_code=" . $course_code . "' class='btn btn-info'>View Profile</a></td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>
