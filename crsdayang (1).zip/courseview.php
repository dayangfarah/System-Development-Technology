<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

include 'headerstudent.php';
include 'dbconnect.php';

$uic = $_SESSION['funame'];

$added_courses = [];
$sql_added = "SELECT r_course FROM tb_registration WHERE r_student='$uic'";
$result_added = mysqli_query($con, $sql_added);
while ($row = mysqli_fetch_assoc($result_added)) {
    $added_courses[] = $row['r_course'];
}

$sql = "SELECT * FROM tb_course";
if (!empty($added_courses)) {
    $course_codes = "'" . implode("','", $added_courses) . "'";
    $sql .= " WHERE c_code NOT IN ($course_codes)";
}

$result = mysqli_query($con, $sql);
?>

<div class="container">
    <h3>Course Registration</h3>

    <input type="text" id="searchInput" class="form-control mb-3" placeholder="Search by Course Code">

    <div class="d-flex gap-2 mb-3">
        <button class="btn btn-info flex-fill" onclick="viewCourses()">View Courses</button>
        <button class="btn btn-warning flex-fill" onclick="viewAddedCourses()">View Added Courses</button>
    </div>

    <form method="POST" action="courseviewprocess.php" onsubmit="return confirmAdd()">
        <div class="mb-3">
            <label for="semesterSelect" class="form-label">Select Semester:</label>
            <select class="form-select" name="selected_semester" id="semesterSelect" required>
                <option value="">-- Select Semester --</option>
                <option value="2024/2025-1">2024/2025-1</option>
                <option value="2024/2025-2">2024/2025-2</option>
            </select>
        </div>

        <table class="table table-striped table-hover" id="courseTable">
            <thead>
                <tr>
                    <th scope="col">Select</th>
                    <th scope="col">Course Code</th>
                    <th scope="col">Course Name</th>
                    <th scope="col">Course Credit</th>
                    <th scope="col">Lecturer Name</th>
                    <th scope="col">Capacity</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_array($result)) {
                    echo "<tr>";
                    echo "<td><input type='checkbox' name='selected_courses[]' value='" . $row['c_code'] . "'></td>";
                    echo "<td class='course-code'>" . $row['c_code'] . "</td>";
                    echo "<td>" . $row['c_name'] . "</td>";
                    echo "<td>" . $row['c_credit'] . "</td>";
                    echo "<td>" . $row['c_lec'] . "</td>";
                    echo "<td>" . $row['max'] . "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>

        <button type="submit" class="btn btn-primary">Add Course</button>
    </form>

</div>

<script>
function viewCourses() {
    var semester = document.getElementById("semesterSelect").value;
    if (semester === "") {
        alert("Please select a semester first.");
    } else {
        window.location.href = "courseview.php?semester=" + semester;
    }
}

function viewAddedCourses() {
    var semester = document.getElementById("semesterSelect").value;
    if (semester === "") {
        alert("Please select a semester first.");
    } else {
        window.location.href = "addcourse.php?semester=" + semester;
    }
}

function confirmAdd() {
    return confirm("Are you sure you want to add the selected courses?");
}

document.getElementById("searchInput").addEventListener("keyup", function() {
    var input = this.value.toLowerCase();
    var rows = document.querySelectorAll("#courseTable tbody tr");

    rows.forEach(function(row) {
        var courseCode = row.querySelector(".course-code").textContent.toLowerCase();
        if (courseCode.includes(input)) {
            row.style.display = "";
        } else {
            row.style.display = "none";
        }
    });
});
</script>


