<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

include 'headeradmin.php';
include 'dbconnect.php';

if (isset($_POST['action']) && isset($_POST['selected_courses'])) {
    $selected_courses = $_POST['selected_courses'];
    $action = $_POST['action'];

    $status = 0;
    if ($action == 'approve') {
        $status = 2;  
    } elseif ($action == 'reject') {
        $status = 3; 
    } elseif ($action == 'cancel') {
        $status = 4;  
    }

    foreach ($selected_courses as $course) {
        list($u_sno, $c_code) = explode('-', $course);

        $update_sql = "UPDATE tb_registration SET r_status = $status WHERE r_student = '$u_sno' AND r_course = '$c_code'";
        if (!mysqli_query($con, $update_sql)) {
            echo "Error updating registration: " . mysqli_error($con);
        }
    }

    header("Location: registrationlist.php");
    exit();
} else {
    echo "No courses selected.";
}

include 'footer.php';
?>
