<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

include 'headerstudent.php';
include 'dbconnect.php';

$uic = $_SESSION['funame'];
$semester = isset($_GET['semester']) ? $_GET['semester'] : '';

$searchTerm = isset($_POST['searchTerm']) ? $_POST['searchTerm'] : '';

$sql = "SELECT tb_registration.*, tb_course.c_name, tb_course.c_credit, tb_course.c_lec, tb_course.max, tb_status.s_desc 
        FROM tb_registration
        LEFT JOIN tb_course ON tb_registration.r_course = tb_course.c_code
        LEFT JOIN tb_status ON tb_registration.r_status = tb_status.s_id
        WHERE tb_registration.r_student = '$uic' 
        AND tb_registration.r_sem = '$semester'";

if ($searchTerm) {
    $sql .= " AND tb_registration.r_course LIKE '%$searchTerm%'";
}

$result = mysqli_query($con, $sql);
?>

<div class="container">
    <h3>My Added Courses (<?php echo htmlspecialchars($semester); ?>)</h3>

    <form method="POST" action="">
        <input type="text" id="searchInput" name="searchTerm" class="form-control mb-3" placeholder="Search by Course Code" value="<?php echo htmlspecialchars($searchTerm); ?>">
    </form>

    <div class="d-flex gap-2 mb-3">
        <button class="btn btn-info flex-fill" onclick="window.location.href='courseview.php'">View Courses</button>
        <button class="btn btn-warning flex-fill" onclick="viewAddedCourses()">View Added Courses</button>
    </div>

    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th scope="col">Course Code</th>
                <th scope="col">Course Name</th>
                <th scope="col">Course Credit</th>
                <th scope="col">Lecturer Name</th>
                <th scope="col">Capacity</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = mysqli_fetch_array($result)) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['r_course']) . "</td>";
                echo "<td>" . htmlspecialchars($row['c_name']) . "</td>";
                echo "<td>" . htmlspecialchars($row['c_credit']) . "</td>";
                echo "<td>" . htmlspecialchars($row['c_lec']) . "</td>";
                echo "<td>" . htmlspecialchars($row['max']) . "</td>";
                echo "<td>" . htmlspecialchars($row['s_desc'] ?? "Unknown") . "</td>";

                echo "<td>
                    <a href='deletecourse.php?course_code=" . urlencode($row['r_course']) . "&semester=" . urlencode($semester) . "' class='btn btn-danger btn-sm'>Delete</a>
                    </td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>

    <div class="d-flex gap-2 mb-3">
        <form method="POST" action="updatesubmission.php">
            <input type="hidden" name="semester" value="<?php echo htmlspecialchars($semester); ?>">
            <button type="submit" name="submit_courses" class="btn btn-success flex-fill">Submit Registration</button>
        </form>

        <form method="POST" action="updatesubmission.php">
            <input type="hidden" name="semester" value="<?php echo htmlspecialchars($semester); ?>">
            <button type="submit" name="cancel_registration" class="btn btn-danger flex-fill">Cancel Registration</button>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>
