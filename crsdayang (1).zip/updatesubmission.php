<?php
include 'dbconnect.php';
session_start();

$uic = $_SESSION['funame'];

if (isset($_POST['submit_courses'])) {
    $semester = $_POST['semester'];

    $get_courses_sql = "SELECT r_course FROM tb_registration WHERE r_student = '$uic' AND r_sem = '$semester'";
    $courses_result = mysqli_query($con, $get_courses_sql);

    while ($course = mysqli_fetch_assoc($courses_result)) {
        $course_code = $course['r_course'];

        $count_query = "SELECT COUNT(*) as num_students FROM tb_registration WHERE r_course = '$course_code' AND r_sem = '$semester'";
        $count_result = mysqli_query($con, $count_query);
        $count_row = mysqli_fetch_assoc($count_result);
        $num_students = $count_row['num_students'];

        $capacity_query = "SELECT max FROM tb_course WHERE c_code = '$course_code'";
        $capacity_result = mysqli_query($con, $capacity_query);
        $capacity_row = mysqli_fetch_assoc($capacity_result);
        $capacity = $capacity_row['max'];

        if ($num_students < $capacity) {
            $update_status = "UPDATE tb_registration SET r_status = 2 WHERE r_student = '$uic' AND r_course = '$course_code' AND r_sem = '$semester'";
            mysqli_query($con, $update_status);
        }
    }
    
    $sql = "UPDATE tb_registration SET r_status = 2 WHERE r_student = '$uic' AND r_sem = '$semester'";
    $message = "All eligible courses have been automatically approved!";
} elseif (isset($_POST['cancel_registration'])) {
    $semester = $_POST['semester'];

    $sql = "UPDATE tb_registration SET r_status = 4 WHERE r_student = '$uic' AND r_sem = '$semester'";
    $message = "All registrations have been canceled. Status reset!";
}

if (isset($sql) && mysqli_query($con, $sql)) {
    echo "<script>alert('$message'); window.location.href = 'addcourse.php?semester=" . $semester . "';</script>";
    exit();
} else {
    echo "Error updating status: " . mysqli_error($con);
}
?>
