<?php 
include('crssession.php');
if(!session_id())
{
    session_start();
}

include 'headeradmin.php'; 
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-4 mb-4">
            <div class="card text-center shadow">
                <div class="card-body">
                    <h3 class="card-title mb-4">Admin Dashboard</h3>
                    <p class="card-text mb-3">Welcome to the Admin Page. You can manage courses and registration here.</p>
                    
                    <!-- Course Button -->
                    <a href="admincourse.php" class="btn btn-primary btn-lg w-100 mb-3">
                        <i class="bi bi-book-fill"></i> Manage Courses
                    </a>

                    <!-- Registration List Button -->
                    <a href="registrationlist.php" class="btn btn-success btn-lg w-100">
                        <i class="bi bi-list-check"></i> View Registration List
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

