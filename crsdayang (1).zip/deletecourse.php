<?php
include 'dbconnect.php';
session_start();

if (!isset($_SESSION['funame'])) {
    header("Location: login.php");
    exit();
}

$uic = $_SESSION['funame'];

if (isset($_GET['course_code']) && isset($_GET['semester'])) {
    $course_code = mysqli_real_escape_string($con, $_GET['course_code']);
    $semester = mysqli_real_escape_string($con, $_GET['semester']);

    $check_sql = "SELECT * FROM tb_registration WHERE r_student='$uic' AND r_course='$course_code' AND r_sem='$semester'";
    $check_result = mysqli_query($con, $check_sql);

    if (mysqli_num_rows($check_result) > 0) {
        $course = mysqli_fetch_assoc($check_result);

        if ($course['r_status'] != 2) {
            $delete_sql = "DELETE FROM tb_registration WHERE r_student='$uic' AND r_course='$course_code' AND r_sem='$semester'";

            if (mysqli_query($con, $delete_sql)) {
                header("Location: addcourse.php?semester=" . urlencode($semester) . "&status=deleted");
                exit();
            } else {
                echo "Error deleting course: " . mysqli_error($con);
            }
        } else {
            echo "Course cannot be deleted because it has been approved.";
        }
    } else {
        echo "Course not found or does not belong to you.";
    }
} else {
    echo "No course selected for deletion.";
}
?>
