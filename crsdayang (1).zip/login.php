<?php include 'headermain.php' ?>
<div class="container">

    <legend>Please fill to login</legend>
 <form method="POST" action ="loginprocess.php">
  <fieldset>

    <div>
      <label for="exampleInputEmail1" class="form-label mt-4"> Please enter your staff or student number</label>
      <input type="text" name="funame" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your staff or student number"required>
  
    </div>
    <div>
<div>
      <label for="exampleInputPassword1" class="form-label mt-4">Create your password</label>
      <input type="password" name ="fpwd" class="form-control" id="exampleInputPassword1" placeholder=" Create Password" autocomplete="off"required>
    </div>
       
    <br><br><br>
    <button type="submit" class="btn btn-primary">Login</button>
    <button type="reset" class="btn btn-outline-warning">Clear Form</button>
    <br><br><br><br><br>
  </fieldset>
</form>



</div>

<?php include 'footer.php' ?>