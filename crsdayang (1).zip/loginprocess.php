<?php
session_start();
include('dbconnect.php');

$funame = $_POST['funame'];
$fpwd = $_POST['fpwd'];

$sql = "SELECT * FROM tb_user 
        WHERE u_sno = '$funame' AND u_pwd = '$fpwd'";

$result = mysqli_query($con, $sql);

$row = mysqli_fetch_array($result);

$count = mysqli_num_rows($result);

if($count == 1) 
{
    $_SESSION['u_sno'] = $row['u_sno'];  
    $_SESSION['funame'] = $funame;

    if($row['u_utype'] == 1)
    {
        header('Location: lecturer.php');
        exit();
    }
    elseif($row['u_utype'] == 2)
    {
        header('Location: student.php');
        exit();
    }
    elseif($row['u_utype'] == 3)
    {
        header('Location: admin.php');
        exit();
    }
}
else 
{
    header('Location: login.php'); 
    exit();
}


mysqli_close($con);
?>
