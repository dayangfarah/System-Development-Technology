<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

include 'headeradmin.php';
include 'dbconnect.php';

$sql = "SELECT * FROM tb_course";
$result = mysqli_query($con, $sql);
?>

<div class="container">
    <h3>All Courses</h3>

    <div class="d-flex justify-content-end mb-3">
        <a href="admincourseadd.php" class="btn btn-success">Add Course</a>
    </div>

    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th scope="col">Course Code</th>
                <th scope="col">Course Name</th>
                <th scope="col">Credit Hour</th>                
                <th scope="col">Lecturer</th>
                <th scope="col">Capacity</th>
                <th scope="col">Semester</th>
                <th scope="col">Action</th> 
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = mysqli_fetch_array($result)) {
                echo "<tr>";
                echo "<td>" . $row['c_code'] . "</td>";
                echo "<td>" . $row['c_name'] . "</td>";
                echo "<td>" . $row['c_credit'] . "</td>";
                echo "<td>" . $row['c_lec'] . "</td>";
                echo "<td>" . $row['max'] . "</td>";
                echo "<td>" . $row['semester'] . "</td>";

                echo "<td>
                        <a href='admincourseedit.php?course_code=" . $row['c_code'] . "' class='btn btn-warning btn-sm'>Edit</a>
                        <a href='javascript:void(0);' class='btn btn-danger btn-sm' onclick='confirmDelete(\"" . $row['c_code'] . "\")'>Delete</a>
                      </td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
       <div class="d-flex mt-4">
        <a href="admin.php" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Back
        </a>
    </div>
</div>

<script>
function confirmDelete(courseCode) {
    if (confirm("Are you sure you want to delete this course?")) {
        window.location.href = 'admindeleteprocess.php?course_code=' + courseCode;
    }
}
</script>

