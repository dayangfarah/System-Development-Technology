<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

include 'headerlecturer.php'; 
include 'dbconnect.php';

$u_sno = isset($_GET['u_sno']) ? $_GET['u_sno'] : '';
$c_code = isset($_GET['c_code']) ? $_GET['c_code'] : '';

// Fetch student details
$sql = "SELECT * FROM student 
        WHERE student.u_sno = '$u_sno'";

$result = mysqli_query($con, $sql);
$student = mysqli_fetch_array($result);

if (!$student) {
    echo "<p>Student not found.</p>";
    exit;
}
?>

<div class="container">
    <h3>Student Profile: <?php echo $student['full_name']; ?></h3>

    <table class="table table-striped table-hover">
        <tbody>
            <tr>
                <th scope="row">Full Name</th>
                <td><?php echo $student['full_name']; ?></td>
            </tr>
            <tr>
                <th scope="row">Student ID</th>
                <td><?php echo $student['u_sno']; ?></td>
            </tr>
            <tr>
                <th scope="row">Programme Code</th>
                <td><?php echo $student['program']; ?></td>
            </tr>
            <tr>
                <th scope="row">Year</th>
                <td><?php echo $student['year']; ?></td>
            </tr>
            <tr>
                <th scope="row">Faculty</th>
                <td><?php echo $student['faculty']; ?></td>
            </tr>
            <tr>
                <th scope="row">Gender</th>
                <td><?php echo $student['gender']; ?></td>
            </tr>
            <tr>
                <th scope="row">Date of Birth</th>
                <td><?php echo $student['Dob']; ?></td>
            </tr>
            <tr>
                <th scope="row">Email</th>
                <td><?php echo $student['email']; ?></td>
            </tr>
            <tr>
                <th scope="row">Phone Number</th>
                <td><?php echo $student['contact']; ?></td>
            </tr>
            <tr>
                <th scope="row">Address</th>
                <td><?php echo $student['address']; ?></td>
            </tr>
            <tr>
                <th scope="row">State</th>
                <td><?php echo $student['state']; ?></td>
            </tr>
        </tbody>
    </table>

    <a href="courseassigned.php?c_code=<?php echo $c_code; ?>" class="btn btn-warning">Back</a> 
</div>

<?php include 'footer.php'; ?>
