<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

include 'headeradmin.php';
?>

<div class="container">
    <h3>Add New Course</h3>

    <form method="POST" action="admincourseaddprocess.php">
        <div>
            <label for="course_code" class="form-label mt-4">Enter Course Code</label>
            <input type="text" name="course_code" class="form-control" id="course_code" placeholder="Course Code" required>
        </div>

        <div>
            <label for="course_name" class="form-label mt-4">Enter Course Name</label>
            <input type="text" name="course_name" class="form-control" id="course_name" placeholder="Course Name" required>
        </div>

        <div>
            <label for="course_credit" class="form-label mt-4">Enter Course Credit Hour</label>
            <input type="text" name="course_credit" class="form-control" id="course_credit" placeholder="Course Credit Hour" required>
        </div>

        <div>
            <label for="lecturer" class="form-label mt-4">Enter Lecturer Assigned</label>
            <input type="text" name="lecturer" class="form-control" id="lecturer" placeholder="Lecturer" required>
        </div>

        <div>
            <label for="capacity" class="form-label mt-4">Enter Capacity</label>
            <input type="text" name="capacity" class="form-control" id="capacity" placeholder="Max Student" required>
        </div>

        <div>
            <label for="semester" class="form-label mt-4">Enter Semester</label>
            <input type="text" name="semester" class="form-control" id="semester" placeholder="Semester" required>
        </div>

        <button type="submit" class="btn btn-outline-light mt-3">Add Course</button>
    </form>
</div>
