<?php
include('dbconnect.php');
session_start();

$uic = $_SESSION['funame']; 

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['selected_courses'], $_POST['selected_semester'])) {
    $selected_courses = $_POST['selected_courses'];
    $selected_semester = $_POST['selected_semester']; 

    foreach ($selected_courses as $course_code) {
        $check_sql = "SELECT * FROM tb_registration WHERE r_student='$uic' AND r_course='$course_code'";
        $check_result = mysqli_query($con, $check_sql);
        
        if (mysqli_num_rows($check_result) == 0) { 
            $sql = "INSERT INTO tb_registration (r_student, r_course, r_status, r_sem) 
                    VALUES ('$uic', '$course_code', '1', '$selected_semester')";
            mysqli_query($con, $sql);
        }
    }

    mysqli_close($con);

    header("Location: courseview.php?status=success");
    exit();
} else {
    header("Location: courseview.php?status=error");
    exit();
}
?>
