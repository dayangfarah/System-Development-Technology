<?php
include('crssession.php');
if(!session_id())
{
	session_start();
}
include 'dbconnect.php';

$uic = $_SESSION['funame'];
$fcourse = $_POST['fcourse'];
$fsem = $_POST['fsem'];

$sql = "INSERT INTO tb_registration (r_student, r_course, r_sem, r_status) 
		VALUES ('$uic', '$fcourse', '$fsem', '1')";

mysqli_query($con, $sql);

mysqli_close($con);

header('Location:courseview.php');


?>