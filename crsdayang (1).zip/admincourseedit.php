<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

include 'headeradmin.php';
include 'dbconnect.php';

if (isset($_GET['course_code'])) {
    $course_code = $_GET['course_code'];

    $sql = "SELECT * FROM tb_course WHERE c_code = '$course_code'";
    $result = mysqli_query($con, $sql);
    $course = mysqli_fetch_assoc($result);

    if (!$course) {
        echo "Course not found!";
        exit();
    }
} else {
    echo "Invalid request!";
    exit();
}
?>

<div class="container">
    <h3>Edit Course - <?php echo $course['c_code']; ?></h3>

    <form method="POST" action="admincourseeditprocess.php?course_code=<?php echo $course['c_code']; ?>">
        <div>
            <label for="course_name" class="form-label mt-4">Course Name</label>
            <input type="text" name="course_name" class="form-control" value="<?php echo $course['c_name']; ?>" required>
        </div>

        <div>
            <label for="course_credit" class="form-label mt-4">Credit Hour</label>
            <input type="text" name="course_credit" class="form-control" value="<?php echo $course['c_credit']; ?>" required>
        </div>

        <div>
            <label for="lecturer" class="form-label mt-4">Lecturer Assigned</label>
            <input type="text" name="lecturer" class="form-control" value="<?php echo $course['c_lec']; ?>" required>
        </div>

        <div>
            <label for="capacity" class="form-label mt-4">Capacity</label>
            <input type="text" name="capacity" class="form-control" value="<?php echo $course['max']; ?>" required>
        </div>

        <div>
            <label for="semester" class="form-label mt-4">Semester</label>
            <input type="text" name="semester" class="form-control" value="<?php echo $course['semester']; ?>" required>
        </div>

        <button type="submit" class="btn btn-outline-light mt-3">Update Course</button>
    </form>
</div>


