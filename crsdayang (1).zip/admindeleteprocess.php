<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

include 'dbconnect.php';

if (isset($_GET['course_code'])) {
    $course_code = $_GET['course_code'];

    $delete_registration_sql = "DELETE FROM tb_registration WHERE r_course = '$course_code'";
    if (!mysqli_query($con, $delete_registration_sql)) {
        echo "Error deleting registrations: " . mysqli_error($con);
        exit();
    }

    $delete_course_sql = "DELETE FROM tb_course WHERE c_code = '$course_code'";
    if (mysqli_query($con, $delete_course_sql)) {
        header("Location: admincourse.php"); 
        exit();
    } else {
        echo "Error deleting course: " . mysqli_error($con);
    }
} else {
    echo "Invalid request!";
}
?>
