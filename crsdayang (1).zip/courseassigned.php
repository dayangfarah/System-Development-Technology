<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

include 'headerlecturer.php';
include 'dbconnect.php';

$uic = $_SESSION['funame'];
$semester = isset($_GET['semester']) ? $_GET['semester'] : '';

?>

<div class="container">
    <h3>Courses Assigned (<?php echo $semester; ?>)</h3>

    <form method="GET" action="courseassigned.php">
        <div class="mb-3">
            <label for="semesterSelect" class="form-label">Select Semester:</label>
            <select class="form-select" name="semester" id="semesterSelect" required onchange="this.form.submit()">
                <option value="">-- Select Semester --</option>
                <option value="2024/2025-1" <?php if ($semester == '2024/2025-1') echo 'selected'; ?>>2024/2025-1</option>
                <option value="2024/2025-2" <?php if ($semester == '2024/2025-2') echo 'selected'; ?>>2024/2025-2</option>
            </select>
        </div>
    </form>

    <?php
    if ($semester) {
        $sql = "SELECT * FROM tb_course WHERE c_lec = '$uic' AND semester = '$semester'";
        $result = mysqli_query($con, $sql);

        if (mysqli_num_rows($result) > 0) {
            echo "<table class='table table-striped table-hover'>
                    <thead>
                        <tr>
                            <th scope='col'>Course Code</th>
                            <th scope='col'>Course Name</th>
                            <th scope='col'>Course Credit</th>
                            <th scope='col'>Lecturer Name</th>
                            <th scope='col'>Capacity</th>
                            <th scope='col'>View Enrolled Students</th> <!-- New Column for View Students link -->
                        </tr>
                    </thead>
                    <tbody>";
            while ($row = mysqli_fetch_array($result)) {
                echo "<tr>
                        <td>" . $row['c_code'] . "</td>
                        <td>" . $row['c_name'] . "</td>
                        <td>" . $row['c_credit'] . "</td>
                        <td>" . $row['c_lec'] . "</td>
                        <td>" . $row['max'] . "</td>
                        <td><a href='viewstudentlist.php?course_code=" . $row['c_code'] . "' class='btn btn-info btn-sm'>View Enrolled Students</a></td>
                    </tr>";
            }
            echo "</tbody></table>";
        } else {
            echo "<p>No courses assigned for this semester.</p>";
        }
    }
    ?>
</div>

<?php include 'footer.php'; ?>
