<?php include 'headermain.php' ?>
<div class="container">

    <legend>Please fill all following details</legend>
 <form method="POST" action ="registerprocess.php">
  <fieldset>

    <div>
      <label for="exampleInputEmail1" class="form-label mt-4"> Please enter your staff or student number</label>
      <input type="text" name="funame" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your staff or student number" required>
    </div>

    <div>
      <label for="exampleInputPassword1" class="form-label mt-4">Create your password</label>
      <input type="password" name ="fpwd" class="form-control" id="exampleInputPassword1" placeholder="Create Password" autocomplete="off" required>
    </div>

    <div>
      <label for="exampleInputPassword1" class="form-label mt-4">Enter Password Again</label>
      <input type="password" name ="fcpwd" class="form-control" id="exampleInputPassword1" placeholder="Enter again" autocomplete="off" required>
    </div>
    
    <div>
      <label for="exampleInputEmail1" class="form-label mt-4">Enter your Email address</label>
      <input type="email" name ="femail" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required>
      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
    </div>
    
    <div>
      <label for="exampleInputEmail1" class="form-label mt-4"> Enter your full name</label>
      <input type="text" name ="fname" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your full name" required>
    </div>

    <div>
      <label for="exampleInputEmail1" class="form-label mt-4"> Enter your contact number</label>
      <input type="text" name ="fcontact" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your contact number" required>
      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
    </div>
    
    <div>
      <label for="exampleSelect1" class="form-label mt-4">Select your state</label>
      <select class="form-select" name ="fstate" id="exampleSelect1" required>
        <option>Johor</option>
        <option>Kedah</option>
        <option>Kelantan</option>
        <option>Melaka</option>
        <option>Negeri Sembilan</option>
        <option>Pahang</option>
        <option>Pulau Pinang</option>
        <option>Perak</option>
        <option>Perlis</option>
        <option>Sabah</option>
        <option>Sarawak</option>
        <option>Selangor</option>
        <option>Terengganu</option>
        <option>Wilayah Persekutuan Kuala Lumpur</option>
        <option>Wilayah Persekutuan Labuan</option>
        <option>Wilayah Persekutuan Putrajaya</option>
      </select>
    </div>

    <div>
      <label for="exampleSelect2" class="form-label mt-4">Select User Type</label>
      <select class="form-select" name ="futype" id="exampleSelect2" required>
        <option value="1">Lecturer</option>
        <option value="2">Student</option>
        <option value="3">Admin</option>
      </select>
    </div>
    
    <br>
    <button type="submit" class="btn btn-primary">Submit</button>
    <button type="reset" class="btn btn-outline-warning">Clear Form</button>
    <br><br><br><br><br>
  </fieldset>
</form>
</div>

<?php include 'footer.php' ?>
