-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jan 31, 2025 at 03:12 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_crs`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `u_sno` varchar(10) NOT NULL,
  `admin_id` int(2) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`u_sno`, `admin_id`, `full_name`, `email`, `contact`) VALUES
('A001', 2, 'admin', 'admin@gmail.com', 198976754);

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `u_sno` varchar(10) NOT NULL,
  `faculty` varchar(30) DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`u_sno`, `faculty`, `full_name`, `email`, `contact`) VALUES
('L001', NULL, 'Aina Abdul', 'aina@gmail.com', 191111111),
('L002', NULL, 'Fazura Abdul', 'faz@gmail.com', 172222222),
('L003', '', 'Aminah', 'aminahkassim@gmail.com', 1212122121),
('L004', '', 'safiya', 'safiya@gmail.com', 1001000102),
('L005', '', 'farra', 'farra@gmail.com', 189765432);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `full_name` varchar(100) NOT NULL,
  `u_sno` varchar(10) NOT NULL,
  `program` varchar(10) NOT NULL,
  `year` int(2) NOT NULL,
  `faculty` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` int(11) NOT NULL,
  `state` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `Dob` date DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`full_name`, `u_sno`, `program`, `year`, `faculty`, `email`, `contact`, `state`, `gender`, `Dob`, `address`) VALUES
('dayang', 'A23CS0000', '', 0, '', 'dayangfarahfarzana@graduate.utm.my', 1129179573, 'Sarawak', '', NULL, NULL),
('Dayang Farah Farzana', 'A23CS0071', 'SECPH', 2, 'Computing', 'dayangfarahfarzana@graduate.utm.my', 1129179573, 'Sarawak', 'Female', '2025-01-30', 'asnfw'),
('farra', 'A23CS0079', '', 0, '', 'farra@gmail.com', 1987653465, 'Johor', '', NULL, NULL),
('safiya', 'A23CS0176', '', 0, '', 'saf@gmail.com', 2147483647, 'Selangor', '', NULL, NULL),
('Syarifah', 'A23CS0252', '', 0, '', 'syarifahqurratulain@graduate.utm.my', 1129179573, 'Perak', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_course`
--

CREATE TABLE `tb_course` (
  `c_code` varchar(10) NOT NULL,
  `c_name` varchar(30) NOT NULL,
  `c_credit` int(11) NOT NULL,
  `c_lec` varchar(10) NOT NULL,
  `max` int(5) NOT NULL,
  `semester` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_course`
--

INSERT INTO `tb_course` (`c_code`, `c_name`, `c_credit`, `c_lec`, `max`, `semester`) VALUES
('KAFA9090', 'Mengaji', 2, 'L004', 50, '2024/2025-1'),
('SECJ2013', 'Data Structure and Algorithm', 3, 'L003', 50, '2024/2025-1'),
('SECP2523', 'Database (WBL)', 3, 'L001', 50, '2024/2025-1'),
('SECP3204', 'Software Engineering (WBL)', 3, 'L002', 50, '2024/2025-2'),
('SECP3433', 'Data Mining', 4, 'L001', 50, '2024/2025-2'),
('SER1213', 'Network Communication', 3, 'L004', 50, '2024/2025-1'),
('ULRF9090', 'Archery', 2, 'L001', 50, '2024/2025-1');

-- --------------------------------------------------------

--
-- Table structure for table `tb_registration`
--

CREATE TABLE `tb_registration` (
  `r_tid` int(11) NOT NULL COMMENT 'This is the transaction ID',
  `r_student` varchar(10) NOT NULL,
  `r_course` varchar(10) NOT NULL,
  `r_sem` varchar(11) NOT NULL,
  `r_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_registration`
--

INSERT INTO `tb_registration` (`r_tid`, `r_student`, `r_course`, `r_sem`, `r_status`) VALUES
(64, 'A23CS0071', 'SECP2523', '2024/2025-1', 2),
(65, 'A23CS0071', 'KAFA9090', '2024/2025-1', 2),
(66, 'A23CS0071', 'SECP3204', '2024/2025-1', 2),
(72, 'A23CS0079', 'SER1213', '2024/2025-1', 5),
(73, 'A23CS0071', 'SECJ2013', '2024/2025-2', 5),
(74, 'A23CS0071', 'SECP3433', '2024/2025-2', 5),
(75, 'A23CS0071', 'SER1213', '2024/2025-2', 5),
(76, 'A23CS0071', 'ULRF9090', '2024/2025-2', 5),
(77, 'A23CS0079', 'ULRF9090', '2024/2025-1', 5),
(78, 'A23CS0079', 'KAFA9090', '2024/2025-2', 5),
(79, 'A23CS0079', 'SECJ2013', '2024/2025-2', 5),
(80, 'A23CS0079', 'SECP2523', '2024/2025-2', 5),
(81, 'A23CS0079', 'SECP3204', '2024/2025-2', 5),
(82, 'A23CS0079', 'SECP3433', '2024/2025-1', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tb_status`
--

CREATE TABLE `tb_status` (
  `s_id` int(11) NOT NULL,
  `s_desc` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_status`
--

INSERT INTO `tb_status` (`s_id`, `s_desc`) VALUES
(1, 'Added'),
(2, 'Approved'),
(3, 'Rejected'),
(4, 'Not Yet Submitted'),
(5, 'Submitted');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `u_sno` varchar(10) NOT NULL,
  `u_pwd` varchar(20) NOT NULL,
  `u_email` varchar(30) NOT NULL,
  `u_name` varchar(50) NOT NULL,
  `u_contact` int(11) NOT NULL,
  `u_state` varchar(20) NOT NULL,
  `u_req` timestamp NULL DEFAULT NULL,
  `u_utype` int(11) NOT NULL,
  `verification_token` varchar(255) DEFAULT NULL,
  `verified` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`u_sno`, `u_pwd`, `u_email`, `u_name`, `u_contact`, `u_state`, `u_req`, `u_utype`, `verification_token`, `verified`) VALUES
('A001', '1234', 'admin@gmail.com', 'admin', 198976754, 'Johor', '2025-01-30 01:38:26', 3, NULL, 0),
('A23CS0000', '$2y$10$XfoqTQiVK9Gqq', 'dayangfarahfarzana@graduate.ut', 'dayang', 1129179573, 'Sarawak', '2025-01-30 23:36:24', 2, '53968d8d1ab2d2e3181216c22fe8c83dfd9b622df66722a97f7a6cfd2dd38b59bbaf4e9c43893e3da97bdb4e053c638f6623', 0),
('A23CS0071', '1234', 'dayangfarahfarzana@graduate.ut', 'Dayang Farah Farzana', 1129179573, 'Sarawak', '2025-01-29 19:32:22', 2, NULL, 0),
('A23CS0079', '1234', 'farra@gmail.com', 'farra', 1987653465, 'Johor', '2025-01-30 02:51:12', 2, NULL, 0),
('A23CS0176', '$2y$10$/5MlVKGr7lUhp', 'saf@gmail.com', 'safiya', 2147483647, 'Selangor', '2025-01-30 14:04:08', 2, NULL, 0),
('A23CS0252', '$2y$10$ox1v9CI3.Bcgu', 'syarifahqurratulain@graduate.u', 'Syarifah', 1129179573, 'Perak', '2025-01-30 20:54:13', 2, '045c2e3bc071642bd1a50eabd0437243b4f34cec7eb8ab8ce0e4cdaad0dc904d50e444368ce585d1503661f5458f44b20294', 0),
('L001', '123456', 'aina@gmail.com', 'Aina Abdul', 191111111, 'Johor', '2023-01-31 16:00:00', 1, NULL, 0),
('L002', '123456', 'faz@gmail.com', 'Fazura Abdul', 172222222, 'Kelantan', '2023-09-30 16:00:00', 1, NULL, 0),
('L003', '$2y$10$AzdsQyG6ZmxST', 'aminahkassim@gmail.com', 'Aminah', 1212122121, 'Johor', '2025-01-29 20:01:59', 1, NULL, 0),
('L004', '$2y$10$9icxQqETQjt6M', 'safiya@gmail.com', 'safiya', 1001000102, 'Sarawak', '2025-01-29 20:03:10', 1, NULL, 0),
('L005', '$2y$10$jVP1N74IsCKbj', 'farra@gmail.com', 'farra', 189765432, 'Johor', '2025-01-29 20:03:41', 1, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_utype`
--

CREATE TABLE `tb_utype` (
  `t_id` int(11) NOT NULL,
  `t_desc` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_utype`
--

INSERT INTO `tb_utype` (`t_id`, `t_desc`) VALUES
(1, 'Lecturer'),
(2, 'Student'),
(3, 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `u_sno` (`u_sno`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD UNIQUE KEY `u_sno` (`u_sno`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`u_sno`),
  ADD KEY `u_sno` (`u_sno`);

--
-- Indexes for table `tb_course`
--
ALTER TABLE `tb_course`
  ADD PRIMARY KEY (`c_code`),
  ADD KEY `c_lec` (`c_lec`);

--
-- Indexes for table `tb_registration`
--
ALTER TABLE `tb_registration`
  ADD PRIMARY KEY (`r_tid`),
  ADD KEY `r_student` (`r_student`),
  ADD KEY `r_course` (`r_course`),
  ADD KEY `r_status` (`r_status`);

--
-- Indexes for table `tb_status`
--
ALTER TABLE `tb_status`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`u_sno`),
  ADD KEY `u_utype` (`u_utype`);

--
-- Indexes for table `tb_utype`
--
ALTER TABLE `tb_utype`
  ADD PRIMARY KEY (`t_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_registration`
--
ALTER TABLE `tb_registration`
  MODIFY `r_tid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'This is the transaction ID', AUTO_INCREMENT=83;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `admin_ibfk_1` FOREIGN KEY (`u_sno`) REFERENCES `tb_user` (`u_sno`);

--
-- Constraints for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD CONSTRAINT `lecturer_ibfk_1` FOREIGN KEY (`u_sno`) REFERENCES `tb_user` (`u_sno`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`u_sno`) REFERENCES `tb_user` (`u_sno`);

--
-- Constraints for table `tb_course`
--
ALTER TABLE `tb_course`
  ADD CONSTRAINT `tb_course_ibfk_1` FOREIGN KEY (`c_lec`) REFERENCES `lecturer` (`u_sno`);

--
-- Constraints for table `tb_registration`
--
ALTER TABLE `tb_registration`
  ADD CONSTRAINT `tb_registration_ibfk_1` FOREIGN KEY (`r_student`) REFERENCES `tb_user` (`u_sno`),
  ADD CONSTRAINT `tb_registration_ibfk_3` FOREIGN KEY (`r_status`) REFERENCES `tb_status` (`s_id`),
  ADD CONSTRAINT `tb_registration_ibfk_4` FOREIGN KEY (`r_course`) REFERENCES `tb_course` (`c_code`);

--
-- Constraints for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD CONSTRAINT `tb_user_ibfk_1` FOREIGN KEY (`u_utype`) REFERENCES `tb_utype` (`t_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
