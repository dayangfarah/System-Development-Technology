<?php
include('crssession.php');
if(!session_id())
{
  session_start();
}

include 'headerstudent.php'; 
include 'dbconnect.php'; 
?>

<div class="container">

    <legend>Course Registration Form</legend>
 <form method="POST" action ="courseregisterprocess.php">
  <fieldset>
    

    <div>
      <label for="exampleSelect1" class="form-label mt-4">Select Course</label>
      <select class="form-select" name ="fcourse" id="exampleSelect1"required>
        <?php
        $sql="SELECT * FROM tb_course";
        $result=mysqli_query($con, $sql);

        while($row=mysqli_fetch_array($result))
        {
          echo"<option value = '".$row['c_code']."'>".$row['c_name']."</option>";
        }
        


        ?>
      </select>
    </div><br>

        <div>
      <label for="exampleSelect1" class="form-label mt-4">Select Semester</label>
      <select class="form-select" name ="fsem" id="exampleSelect1"required>
       
        <option>2024/2025-1</option>
        <option>2024/2025-2</option>
        <option>2024/2025-3</option>

        
      </select>
    </div><br>
    
    <button type="submit" class="btn btn-primary">Register</button>
    <button type="reset" class="btn btn-outline-warning">Clear Form</button>
    <br><br><br><br><br>
  </fieldset>
</form>



</div>

<?php include 'footer.php' ?>