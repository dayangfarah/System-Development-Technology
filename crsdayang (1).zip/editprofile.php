<?php
include('crssession.php');
if(!session_id()) {
    session_start();    
}

include 'dbconnect.php';

$u_sno = $_SESSION['u_sno']; 

$query = "SELECT * FROM student WHERE u_sno = '$u_sno'";
$result = mysqli_query($con, $query);

if (mysqli_num_rows($result) == 0) {
    echo "<p style='color:red;'>Error: Student not found in the database.</p>";
    exit;
}

$student = mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $program = $_POST['program'];
    $year = $_POST['year'];
    $faculty = $_POST['faculty'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $address = $_POST['address'];
    $state = $_POST['state'];

    $update_sql = "UPDATE student 
                   SET full_name = '$full_name', program = '$program', year = '$year', 
                       faculty = '$faculty', gender = '$gender', Dob = '$dob', email = '$email', 
                       contact = '$contact', address = '$address', state = '$state'
                   WHERE u_sno = '$u_sno'";

    if (mysqli_query($con, $update_sql)) {
        echo "<script>alert('Profile updated successfully!'); window.location.href='profstudent.php';</script>";
        exit;
    } else {
        echo "<p style='color:red;'>Error updating profile: " . mysqli_error($con) . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Edit Profile</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <style>
    .footer {
       position: fixed;
       left: 0;
       bottom: 0;
       width: 100%;
       background-color: #d4d1ce;
       color: white;
       text-align: center;
    }
  </style>
</head>
<body>

<?php include 'headerstudent.php'; ?>

<div class="container">
  <h3>Edit Profile</h3>
  <form method="POST" action="editprofile.php">
    <div class="mb-3">
      <label for="full_name" class="form-label">Full Name</label>
      <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo $student['full_name']; ?>" required>
    </div>
    <div class="mb-3">
      <label for="program" class="form-label">Programme Code</label>
      <input type="text" class="form-control" id="program" name="program" value="<?php echo $student['program']; ?>" required>
    </div>
    <div class="mb-3">
      <label for="year" class="form-label">Year</label>
      <input type="text" class="form-control" id="year" name="year" value="<?php echo $student['year']; ?>" required>
    </div>
    <div class="mb-3">
      <label for="faculty" class="form-label">Faculty</label>
      <input type="text" class="form-control" id="faculty" name="faculty" value="<?php echo $student['faculty']; ?>" required>
    </div>
    <div class="mb-3">
      <label for="gender" class="form-label">Gender</label>
      <select class="form-control" id="gender" name="gender" required>
        <option value="Male" <?php if ($student['gender'] == 'Male') echo 'selected'; ?>>Male</option>
        <option value="Female" <?php if ($student['gender'] == 'Female') echo 'selected'; ?>>Female</option>
      </select>
    </div>
    <div class="mb-3">
      <label for="dob" class="form-label">Date of Birth</label>
      <input type="date" class="form-control" id="dob" name="dob" value="<?php echo $student['Dob']; ?>" required>
    </div>
    <div class="mb-3">
      <label for="email" class="form-label">Email</label>
      <input type="email" class="form-control" id="email" name="email" value="<?php echo $student['email']; ?>" required>
    </div>
    <div class="mb-3">
      <label for="contact" class="form-label">Phone Number</label>
      <input type="text" class="form-control" id="contact" name="contact" value="<?php echo $student['contact']; ?>" required>
    </div>
    <div class="mb-3">
      <label for="address" class="form-label">Address</label>
      <input type="text" class="form-control" id="address" name="address" value="<?php echo $student['address']; ?>" required>
    </div>
    <div class="mb-3">
      <label for="state" class="form-label">State</label>
      <input type="text" class="form-control" id="state" name="state" value="<?php echo $student['state']; ?>" required>
    </div>
    <button type="submit" class="btn btn-success mb-4">Update Profile</button>
    <a href="profstudent.php" class="btn btn-secondary mb-4">Cancel</a>
  </form>
</div>


</body>
</html>
