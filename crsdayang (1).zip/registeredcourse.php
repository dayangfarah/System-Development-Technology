<?php
session_start();
include('crssession.php');
include 'headerstudent.php';  
include 'dbconnect.php';

if (!isset($_SESSION['u_sno'])) {
    echo "<p>You are not logged in. Please log in to access this page.</p>";
    exit;
}

$u_sno = $_SESSION['u_sno'];

$semester_query = "SELECT DISTINCT r_sem FROM tb_registration ORDER BY r_sem ASC";
$semester_result = mysqli_query($con, $semester_query);

$selected_semester = isset($_POST['semester']) ? $_POST['semester'] : '';

?>

<div class="container">
    <h3>Registered Courses</h3>

    <form method="POST" action="" class="mb-3">
        <label for="semester" class="form-label">Select Semester:</label>
        <select name="semester" id="semester" class="form-select" required>
            <option value="">-- Select Semester --</option>
            <?php
            while ($row = mysqli_fetch_assoc($semester_result)) {
                $semester_value = $row['r_sem'];
                $selected = ($selected_semester == $semester_value) ? 'selected' : '';
                echo "<option value='$semester_value' $selected>$semester_value</option>";
            }
            ?>
        </select>
        <button type="submit" class="btn btn-primary mt-2">View Courses</button>
    </form>

    <?php
    if (!empty($selected_semester)) {
        $course_query = "SELECT tb_course.c_name, tb_registration.r_course 
                         FROM tb_registration 
                         LEFT JOIN tb_course ON tb_registration.r_course = tb_course.c_code
                         WHERE tb_registration.r_student = '$u_sno' 
                         AND tb_registration.r_sem = '$selected_semester' 
                         AND tb_registration.r_status = 2";
        
        $course_result = mysqli_query($con, $course_query);

        if (mysqli_num_rows($course_result) > 0) {
            echo "<table class='table table-striped table-hover'>";
            echo "<thead><tr><th>Course Code</th><th>Course Name</th></tr></thead>";
            echo "<tbody>";
            while ($row = mysqli_fetch_assoc($course_result)) {
                echo "<tr>";
                echo "<td>{$row['r_course']}</td>";
                echo "<td>{$row['c_name']}</td>";     
                echo "</tr>";
            }
            echo "</tbody></table>";
        } else {
            echo "<p>No courses registered for this semester.</p>";
        }
    }
    ?>

</div>

<?php include 'footer.php'; ?>
