<div class="footer">
  <p>CRS developed by Safiya @ 2024</p>
</div>

</body>
</html>