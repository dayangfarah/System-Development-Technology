<?php 
include('crssession.php');
if(!session_id())
{
	session_start();
}
include 'headerlec.php'; 
?>
<div class="container">
Lecturer Page
</div>
<?php include 'footer.php' ?>